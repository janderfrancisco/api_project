<?php $__env->startComponent('mail::message'); ?>
# AVISO USUÁRIO BLOQUEADO:

O usuário ID: <?php echo e($data['id']); ?> - Nome: **<?php echo e($data['name']); ?>**  

foi bloqueado no curso ID: <?php echo e($data['course_id']); ?> - Curso:  **<?php echo e($data['course_name']); ?>** 

módulo ID: <?php echo e($data['module_id']); ?> - Nome:  **<?php echo e($data['module_name']); ?>**
 
 
Obrigado,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\xampp\htdocs\ead_api\resources\views/Email/userBlock.blade.php ENDPATH**/ ?>