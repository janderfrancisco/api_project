title: API Reference

language_tabs:
<?php $__currentLoopData = $settings['languages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
- <?php echo e($language); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

includes:

search: true

toc_footers:
- <a href='http://github.com/mpociot/documentarian'>Documentation Powered by Documentarian</a><?php /**PATH E:\xampp\htdocs\curruculo_api\vendor\mpociot\laravel-apidoc-generator\src/../resources/views//partials/frontmatter.blade.php ENDPATH**/ ?>