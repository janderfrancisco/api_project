<?php
 
 
return [
    // 'gclientSoap'   => 'http://rheims.ddns.net:8081/g5-senior-services/rs_Synccom_senior_g5_rh_rs_dadosCurriculo?wsdl', 
    // 'gintegracoes'  => 'http://rheims.ddns.net:8081/g5-senior-services/rs_Synccom_senior_g5_rh_rs_dadosCurriculo?wsdl', 
    // 'gbuscavagas'   => 'http://rheims.ddns.net:8081/g5-senior-services/rs_Synccom_senior_g5_rh_rs_integracoes?wsdl', 
    // 'gfoto'         => 'http://rheims.ddns.net:8081/g5-senior-services/rs_Asynccom_senior_g5_rh_rs_custom_fotocandidato?wsdl',
    // 'garquivo'      => 'http://rheims.ddns.net:8081/g5-senior-services/rs_Asynccom_senior_g5_rh_rs_custom_arquivocandidato?wsdl',

    'opportunity_url'   => 'http://laswts06senior-edocs:8080/g5-senior-services/rs_Synccom_senior_g5_rh_rs_integracoes?wsdl',
    'curriculum_url'    => 'http://laswts06senior-edocs:8080/g5-senior-services/rs_Synccom_senior_g5_rh_rs_dadosCurriculo?wsdl',
    'user'              => 'webser',
    'password'          => 'web@2123',
    'numemp'            => 1,
    'encryption'        => 0
];
